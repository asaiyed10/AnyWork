package connectme.idea1;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Ahson on 1/7/17.
 */

public class houseKeeping extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.housekeeping);
    }
}

